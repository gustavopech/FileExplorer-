package fileexplorer;
/**
* This Program will mimic File explorer as well as depict storage
*
* @author  Gustavo Pech, Travis Nguyen 
* @version 1.0
* @since   2021-04-24
*/
public class GUIIntro {
	public static void main(String[] args){
		App app = new App();
		app.go();
	}
}
